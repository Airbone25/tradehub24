import React from 'react';

const CookiePolicy: React.FC = () => {
  return (
    <div>
      <h1>Cookie Policy</h1>
      <p>This page explains how we use cookies to improve your experience.</p>
    </div>
  );
};

export default CookiePolicy;
