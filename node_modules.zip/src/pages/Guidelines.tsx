import React from 'react';

const Guidelines: React.FC = () => {
  return (
    <div>
      <h1>Community Guidelines</h1>
      <p>These are our guidelines to ensure a safe and respectful community.</p>
    </div>
  );
};

export default Guidelines;
